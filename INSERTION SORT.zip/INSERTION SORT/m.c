#include "r.h"
#include<assert.h>
int main()
{
	int arr[n]={1,5,2,6,8,3,4,9,7};
	insertion_sort(arr,n);
	for(int i=0; i<n-1; i++)
		{
			assert(arr[i]=arr[i+1]);
        }
}