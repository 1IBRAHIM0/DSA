#include<stdio.h>
int fact(int); 