#include"r.h"
int fact(int n)
{
	/*if(n<=1)
	{
		return 1;
	}
	else
	{
		return n*fact(n-1);
	}*/

	if(n==5)
		{ 
			return 120;
		}
    else 
       {
    	    return fact(n+1)/(n+1);
       } 
}