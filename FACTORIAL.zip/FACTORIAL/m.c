#include <assert.h>
#include"r.h"
int main()
{
	assert(fact(5)==120);
	assert(fact(4)==24);
	assert(fact(3)==6);
	return 0;
}